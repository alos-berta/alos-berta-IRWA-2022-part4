import json
import random

class AnalyticsData:
    """
    An in memory persistence object.
    Declare more variables to hold analytics tables.
    """
    # statistics table 1
    # fact_clicks is a dictionary with the click counters: key = doc id | value = click counter
    fact_clicks = dict([])

    # statistics table 2 
    # fact_browser is a dictionary with the browsers: key = browser | value = counter
    fact_browser = dict([])

    # statistics table 3 
    # fact_OpSys is a dictionary with the Operating systems: key = Operating system | value = counter
    fact_OpSys = dict([])

    # statistics table 4 
    # fact_time is a dictionary with the hour: key = hour | value = counter
    fact_time = dict([])

    # statistics table 5 
    # fact_date is a dictionary with the date: key = date | value = counter
    fact_date = dict([])
  
    # statistics table 6 
    # fact_ip is a dictionary with the IP: key = IP | value = counter
    fact_ip = dict([])
    
    # statistics table 7 
    # fact_number_of_terms is a dictionary with the number of terms: key = query | value = the length of the query
    fact_number_of_terms = dict([])
    
    # statistics table 8 
    # fact_query_related is a dictionary with a list of queries related to each doc: key = document id | value = list of queries
    fact_query_related = dict([])
    
    def save_query_terms(self, terms: str) -> int:
        print(self)
        return random.randint(0, 100000)


class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter
        
    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)





 
