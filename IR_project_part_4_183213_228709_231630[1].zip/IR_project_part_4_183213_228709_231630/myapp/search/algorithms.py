from collections import defaultdict
import pandas as pd
import math
import numpy as np
from array import array
import collections
from numpy import linalg as la
from myapp.search.objects import Document
import re
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import nltk
nltk.download('stopwords')

def search_in_corpus(query, corpus):
    # 1. create create_tfidf_index
    index, tf, idf = create_index_tfidf(corpus, len(corpus))

    # 2. apply ranking
    return search_tf_idf(query, index, idf, tf)

#Function to preprocess data
def build_terms(line):
    """
    Preprocess the text removing stop words, stemming, transforming in 
    lowercase, removing URLs and emojis, removing everything it is not a digit 
    nor number and return the tokens of the text.
    
    Argument:
    line -- string (text) to be preprocessed
    
    Returns:
    line - a list of tokens corresponding to the input text after the preprocessing
    """
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))
    line=re.sub(r'[\W_]+', ' ', line) #BONUS: Removing anything is not a letter or digit
    line = line.lower() 
    line = line.split()  # Tokenize the text to get a list of terms
    line = [x for x in line if x not in stop_words]  # eliminate the stopwords
    line = [stemmer.stem(word) for word in line] # perform stemming (HINT: use List Comprehension)
    line = [l for l in line if "http" not in l ] #BONUS: Removing the URLs from the line
    #line = [emojis_out(l) for l in line ] ##BONUS: removing the emojis from the line
    return line

def create_index_tfidf(corpus, num_documents):
    
    index = defaultdict(list)
    tf = defaultdict(list)
    df = defaultdict(int)  
    idf = defaultdict(float)
    title_index = defaultdict(str)
    
    ll = list(corpus.values())
    for i in range(num_documents):
        line: Document = ll[i]  
        page_id = line.id
        terms = build_terms(line.description)
        title = line.title
        title_index[page_id] = title 
        current_page_index = {}
        
        for position, term in enumerate(terms):  ## terms contains page_title + page_text
            try:
                #if the term is already in the dict append position to the corresponding list
                current_page_index[term][1].append(position) 
            except:
                #add the new term as dict key and initialize the array of positions and add the position
                current_page_index[term] = [page_id, array('I', [position])] 

        # Normalize term frequencies
        norm = 0
        for term, posting in current_page_index.items():
            norm += len(posting[1]) ** 2
        norm = math.sqrt(norm)

        # Calculate the tf and df weights
        for term, posting in current_page_index.items():
            tf[term].append(np.round(len(posting[1]) / norm, 4)) 
            df[term] += 1 
        
        # merge te current page index with the main index
        for term_page, posting_page in current_page_index.items():
            index[term_page].append(posting_page)
        
        # Compute IDF
        for term in df:
            idf[term] = np.round(np.log(float(num_documents / df[term])), 4)

    return index, tf, idf


def rank_documents(terms, docs, index, idf, tf):
    
    doc_vectors = defaultdict(lambda: [0] * len(terms)) 
    query_vector = [0] * len(terms)

    # computing the norm for the query tf
    query_terms_count = collections.Counter(terms)  # get the frequency of each term in the query
    query_norm = la.norm(list(query_terms_count.values()))

    for termIndex, term in enumerate(terms):  # termIndex is the index of the term in the query
        if term not in index:
            continue

        # Compute tf*idf
        query_vector[termIndex] = query_terms_count[term] / query_norm * idf[term]

        # Generate doc_vectors for matching docs
        for doc_index, (doc, postings) in enumerate(index[term]):
            if doc in docs:
                doc_vectors[doc][termIndex] = tf[term][doc_index] * idf[term]

    # Calculate the score of each doc 
    # Computing the cosine similarity between queyVector and each docVector
    doc_scores = [[np.dot(curDocVec, query_vector), doc] for doc, curDocVec in doc_vectors.items()]
    doc_scores.sort(reverse=True)
    result_docs = [x[1] for x in doc_scores]
    result_scores = [x[0] for x in doc_scores]
    
    return result_docs, result_scores


def search_tf_idf(query, index, idf, tf): 
    """
    output is the list of documents that contain any of the query terms. 
    So, we will get the list of documents for each query term, and take the union of them.
    """
    query = build_terms(query)
    docs = set()
    for term in query:
        try:
        # store in term_docs the ids of the docs that contain "term"
            term_docs = [posting[0] for posting in index[term]]
            # docs = docs Union term_docs
            docs |= set(term_docs)
        except:
            #term is not in index
            pass
    docs = list(docs)
    ranked_docs, result_scores = rank_documents(query, docs, index, idf, tf)
    return ranked_docs, result_scores


